/*
* File: addRemove.c
* Description: Implementation for EasyWater8000 controller class addRemove
* Project: PRJ3
* 
* Author: Bjørn Sørensen
*/

#include "addRemove.h"

// Private data

// Public methods
void addRemove_init( )
{

}

int addRemove_verify( )
{
    return 0;
}