/*
* File: addRemove.h
* Description: Header for EasyWater8000 controller class addRemove
* Project: PRJ3
* 
* Author: Bjørn Sørensen
*/

#ifndef ADDREMOVE_H
#define ADDREMOVE_H

extern void addRemove_init( );
extern int addRemove_verify( );

#endif // ifndef ADDREMOVE_H
