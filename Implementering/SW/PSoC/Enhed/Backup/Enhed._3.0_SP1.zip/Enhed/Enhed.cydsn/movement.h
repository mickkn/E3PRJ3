

#include <project.h>
#include "loaddata.h"

extern void movement_init();

//ISR prototype
CY_ISR_PROTO(P_PIR);